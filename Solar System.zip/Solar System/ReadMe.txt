please import all of these python packages before running script

numpy
math
opengl
pygame
pkg_resources
os
opengl accalerated
open gl GLUT